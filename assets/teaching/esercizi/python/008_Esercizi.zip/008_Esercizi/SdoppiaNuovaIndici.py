def sdoppiaConIndici(A):
    if type(A)!=list:
        return None

    NewA = []

    if len(A)==0:
        return NewA

    NewA.append(A[0]) #il primo elemento va sicuramente

    for i in range(1,len(A)): #scorro A senza considerare il primo elemento
        if A[i] != NewA[-1]:
            NewA.append(A[i])

    return NewA

stringa = input("Inserisci una stringa: ")
carattere = input("Inserisci un carattere: ")

n = 0
for c in stringa:
    if c == carattere:
        n = n + 1

print("Il carattere", carattere, "compare", n, "volte")

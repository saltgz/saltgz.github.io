def ListaFibonacci(n):
    if n<1:
        return []
    if n==1:
        return [1]
    if n==2:
        return [1,1]

    l = ListaFibonacci(n-1)
    #NB: usando append non potevamo fare direttamente return
    l.append(l[-1]+l[-2]) 
    return l

print(ListaFibonacci(-1))
print(ListaFibonacci(0))
print(ListaFibonacci(1))
print(ListaFibonacci(2))
print(ListaFibonacci(3))
print(ListaFibonacci(4))
print(ListaFibonacci(10)) 
        

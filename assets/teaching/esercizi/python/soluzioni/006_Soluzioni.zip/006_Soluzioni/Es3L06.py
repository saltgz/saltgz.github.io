import string
def contaPunteggiatura():
    stringa = input("Insersci una stringa: ")
    n = 0 #accumulatore per conteggio 
    i = 0 #indice per caratteri nella stringa
    while i<len(stringa):
        if stringa[i] in string.punctuation:
            n +=1
        i +=1
    print("Il numero di segni di punteggiatura è",n)
    return n

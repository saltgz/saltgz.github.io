def copiaprofonda(L):
    newL = []
    for e in L:
        if type(e)==list:
            newL.append(copiaprofonda(e))
        else:
            newL.append(e)
    return newL

def copiaprofonda2(L):
    if L==[]:
        return []
    
    if type(L[0])!=list: #se trovo un valore, lo copio
        primo = [L[0]]
    else: #se trovo una lista, vado ricorsivamente
        primo = [copiaprofonda2(L[0])]
    
    return primo+copiaprofonda2(L[1:])
    
A = [1, [[2,4.5],[3,"ciao"]]]
B = copiaprofonda2(A)
print("A", A)
print("B", B)
A[0] = 42
print("A", A)
print("B", B)

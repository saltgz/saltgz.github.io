def sconto(age):
    if ((age < 6) or (age > 70)):
        return "Gratis"
    elif (age <= 12): #NB: ho già verificato che è >=6
        return "Sconto bambini"
    elif (age >= 60):
        return "Sconto pensionati"
    else:
        return "Biglietto intero"

import math

"""
Esistono molti algoritmi diversi:
https://en.wikipedia.org/wiki/Primality_test
"""

def isPrime(n):
    """Determina se un numero n è primo o no"""
    if n<2:
        return False
    
    #cerco un divisore tra 2 e radiceQuadrata(n)
    i = 2
    while i <= int(math.sqrt(n)):
        if n % i == 0:
            return False  #se lo trovo, il numero non è primo
        i += 1

    return True #se sono arrivato fin qui, non ho trovato divisori. Quindi è primo.


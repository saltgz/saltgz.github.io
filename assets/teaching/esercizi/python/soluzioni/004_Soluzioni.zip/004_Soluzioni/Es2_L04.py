s1 = input("Prima stringa: ")
s2 = input("Seconda stringa: ")

if s1 < s2:
    print(s1, s2)
elif s1 > s2:
    print(s2, s1)
else:
    print(s1)

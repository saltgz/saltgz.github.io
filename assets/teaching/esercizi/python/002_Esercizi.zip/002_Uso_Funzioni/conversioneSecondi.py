def secondiInOreMinSec(secondiTotali):
    """Converte i secondiTotali in ore, minuti, secondi"""

    #divisione intera, ottengo le ore "piene"
    ore = secondiTotali // 3600

    #il resto della divisione sono i secondi che restano
    secondiRimanenti = secondiTotali % 3600

    #dividendoli per 60 vedo quanti minuti "pieni" restano
    minuti = secondiRimanenti // 60

    #il resto della divisione mi dirà quanti secondi (meno di 60) restano
    secondi = secondiRimanenti % 60

    #posso restituire più valori
    return ore, minuti, secondi  

#FUNZIONE CORRETTA

def crescente(t):
    """Funzione che prende come parametro una tupla t
    e restituisce True se tutti i valroi sono in ordine strettamente crescente,
    False altrimenti"""
    for i in range(len(t)-1): #t-1 perché nel corpo accedo a t+1
        if t[i+1]<=t[i]: #basta un controesempio
            return False #se trovo un controesempio: False
    return True #se arrivo qui, non ho trovato controesempi: True


print(crescente((1,2,3,4,5,6))) #Atteso: True
print(crescente((1,2,2,4))) #Atteso: False
print(crescente((7,1,4,5,3))) #Atteso: False
print(crescente((1,))) #Atteso: True
print(crescente(())) #Atteso: True

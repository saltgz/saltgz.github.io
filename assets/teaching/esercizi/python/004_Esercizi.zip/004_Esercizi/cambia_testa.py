def cambia_testa(t):
    """Funzione che chiede un valore in input all'utente e lo sostituisce al primo elemento di una stringa passata come parametro"""
    return (eval(input("Inserisci il nuovo valore di testa: ")),)+t[1:]

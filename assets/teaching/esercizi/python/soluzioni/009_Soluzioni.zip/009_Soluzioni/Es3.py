def rimuovi(L, e):
    if L==[]:
        return []
    if e not in L:
        return L.copy()
    LR = rimuovi(L[1:], e)
    if L[0]==e:
        return LR
    else:
        return [L[0]]+LR

print(rimuovi([],3))
print(rimuovi([2,4,6],3))
print(rimuovi([3,2,3,4,3,3,6,3],3))

def e_lista_num(l):
    if type(l)!=list:
        return False
    for e in l:
        if type(e) not in (int, float, complex):
            return False
    return True

def e_matrice(M):
    if type(M)!=list:
        return False
    r = len(M)   #righe
    if r == 0: return True
    if e_lista_num(M): #e' una lista, non una matrice
        return False
    if type(M[0])==list:
        c = len(M[0]) #colonne
    else: return False
    for riga in M:
        if not (e_lista_num(riga) and len(riga)==c):
            return False
    return True

def stampaMatrice(M):
    if e_matrice(M):        
        for riga in M:
            for e in riga:
                print(e, end='\t')
            print() #a capo dopo ogni riga
    else:
        print("Non è una matrice")
        print(M)

def sono_liste_molt(U,V):
    if not (e_lista_num(U) and e_lista_num(V)):
        return False
    return len(U)==len(V)

def molt_liste(U,V):
    if sono_liste_molt(U,V):
        pr_sc = 0
        for i in range(len(V)):
            pr_sc = pr_sc + (U[i]*V[i])
        return pr_sc
    else:
        return None

def molt_liste_2(U,V):
    if sono_liste_molt(U,V):
        pr_sc = 0
        for eu, ev in zip(U, V): #lo posso fare perche' hanno la stessa dim
            pr_sc = pr_sc + eu*ev
        return pr_sc
    else:
        return None

def righe_col_matrice(M):
    if e_matrice(M):
        r = len(M)
        if r == 0:
            return 0, 0
        else:
            c = len(M[0])
            return r, c
    else:
        return None, None

def sono_matr_molt(M,N):
    if not (e_matrice(M) and e_matrice(N)):
        return False
    rm, cm = righe_col_matrice(M)
    rn, cn = righe_col_matrice(N)
    return cm == rn

def trasposta(M):
    if e_matrice(M):
        MT = []
        r = len(M)
        if r == 0: #vuota
            return MT
        else:
            c = len(M[0])
            for i in range(c): #ciclo sulle colonne
                col = [] #i-ma colonna
                for j in range(r): #ciclo sulle righe
                    col.append(M[j][i])
                #ora in col ho la i-ma colonna, che diventa l'i-ma riga
                MT.append(col)
            return MT
    else:
        print("Non e' una matrice")

def molt_mat(A,B):
    if sono_matr_molt(A,B): # se posso eseguire la molt
        AB = [] #prodotto
        BT = trasposta(B) #trasposta di B
        for i in range(len(A)): #righe di A (e quindi di AB)
          riga = [] #i-ma riga di AB
          for j in range(len(BT)):#righe di BT (= col di B e AB)
                ij = molt_liste(A[i],BT[j]) #prodotto scalare
                riga.append(ij) #inseriesco elemento nella riga
          AB.append(riga) #inserisco la riga nel risultato
        return AB
    else:
        print("Matrici non moltiplicabili")
        return None

if __name__ == "__main__":
    A = [[1, 2, 3], [4, 5, 6]]
    B = [[2, 1, 3, 1], [1, 2, 3, 4], [4, 1, 2, 3]]
    AB = molt_mat(A,B)
    V = [[2, 4, 6]]
    VB = molt_mat(V, B)
    BV = molt_mat(B, V) #impossibile
    C = [[1], [3], [5]]
    AC = molt_mat(A,C)
    VC = molt_mat(V,C)

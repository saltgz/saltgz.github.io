import math
def equazione_sec_grado(a,b,c): 
    if a==0 and b==0 and c==0:
        print("Equazione indeterminata: a, b, c nulli")
        return None
    elif a==0 and b==0:
        print("Equazione impossibile: a e b nulli")
        return None
    elif a==0:
        return -c/b
    else:
        delta = b**2-4*a*c
        if delta<0:
            print("Equazione impossibile: delta < 0")
            return None
        else:
            radice_delta=math.sqrt(delta)
            x1 = (-b-radice_delta)/(2*a)
            x2 = (-b+radice_delta)/(2*a)
            return x1, x2


print("Programma che risolve le equazioni di secondo grado ax^2+bx+c=0")
print()
a = float(input("scrivi il valore di a: "))
b = float(input("scrivi il valore di b: "))
c = float(input("scrivi il valore di c: "))
result = equazione_sec_grado(a,b,c)
if result!= None:
    if type(result) == tuple:
        print("L'equazione ha due soluzioni distinte")
        print("x1 =", result[0])
        print("x2 =", result[1])
    else:
        print("Equazione di primo grado: due soluzioni coincidenti")
        print("x =", result)


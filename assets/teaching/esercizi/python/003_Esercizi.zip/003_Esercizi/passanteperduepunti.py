import math
def retta_passante_per(x0,y0,x1,y1):
    if (x0==x1) and (y0==y1):
        print("I punti sono sovrapposti")
    else:
        m = (y0-y1)/(x0-x1)
        q = y0-m*x0
        print("La retta passante per (",x0,",",y0,") e (",x1,",",y1,") ha equazione ",
              "y = ",m,"x + ",q, sep='')

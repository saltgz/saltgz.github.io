def vocali(s):
    i = 0
    while i<len(s):
        if s[i].lower() in "aeiou":
            print(s[i])
        i+=1

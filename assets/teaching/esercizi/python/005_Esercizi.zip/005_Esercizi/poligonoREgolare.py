import turtle
def poligono_regolare(n, l):
    if n>2:
        for i in range(n):
            turtle.forward(l)
            turtle.left(360/n)

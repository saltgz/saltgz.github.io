km = 10
miglia = km/1.61
s = 42 * 60 + 42
m = s / 60
h = m / 60
print("km/min", km/m)
print("km/h", km/h)
print("mph", miglia/h)
print("mpm", miglia/m)

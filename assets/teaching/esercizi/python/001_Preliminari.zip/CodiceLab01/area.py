l = 5
area = l*l
print(area)

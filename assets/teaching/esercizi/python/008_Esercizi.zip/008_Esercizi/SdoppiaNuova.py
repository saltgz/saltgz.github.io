def sdoppia(A):
    if type(A)!=list:
        return None

    NewA = []

    if len(A)==0:
        return NewA

    NewA.append(A[0]) #il primo elemento va sicuramente

    for e in A[1:]: #scorro A senza considerare il primo elemento
        if e != NewA[-1]:
            NewA.append(e)

    return NewA

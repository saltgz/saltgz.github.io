def capital(C,r,n,t):
    M = C*(1 + r/n)**(n*t)
    return M

C = 10000
r = 0.08
t = 2
n = 12
M = capital(C,r,n,t)
print("Capitale finale per investimento di ", C,", calcolo mensile, tasso ", r*100, "%, per ", t," anni: ", M, sep = '')

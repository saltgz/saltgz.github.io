import matrici

def matrice_quadrata(Q):
    return matrici.righe(Q) == matrici.colonne(Q)


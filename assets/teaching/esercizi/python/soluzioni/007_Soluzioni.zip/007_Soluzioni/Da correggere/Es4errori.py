#ESERCIZIO CON ERRORI

"""Date due tuple di naturali tutti distinti A e B, diciamo che costituiscono un involucro
se una delle due compare come sottosequenza contigua dentro l’altra, con almeno un elemento
a sinistra e almeno un elemento a destra che non le appartengono. Esempio: (0,1,2,3,11,16) e
(1,2,3) costituiscono un involucro; (1,2,3) e (1,2,3,11) non lo sono.
Se una delle due e' vuota, l’altra deve avere almeno due elementi (la sequenza vuota “sta nel mezzo” ai due elementi,
uno a sinistra, uno a destra).
Si scriva una funzione Python
involucro(A,B) che, presi come parametri due tuple di naturali restituisce True sse esse costituiscono un involucro.
Provare infine la funzione chiedendo in input due tuple.
"""


def involucro(A,B):
    A = tuple(input("Inserisci una tupla: ")
    B = tuple(input("Inserisci una tupla: ")

    if len(A)=0 or len(B)=0:
        if (len(A)==0 and len (B)>=2) or ( len (A)>=2 and len (B)==0):
            return True
    return False # una delle due e’ vuota e l’altra non ha almeno due elementi

    if len(A)>len(B):
        return inv_aux(A,B)
    else:
        return inv_aux(B,A)

    
def inv_aux(C,L): # L e’ la tupla lunga e C quella corta; non sono vuote
    i = 2 # cerchiamo in L, se c’e’, l’ inizio di C, partendo dal secondo elemento
          # per lasciare un elemento a sinistra

    while i <= len(L)-len(C) and L[i]==C[0]:
        # il controllo  assicura ci sia in L un elemento a destra di C
        i += 1
    if i == len(L)-len(C): # se C[0] non e ’ in L (ad un indice sufficientemente "piccolo" per lasciare un elemento a destra di C), restituisci False
        return False

    j = 2 # verifica che C compaia in L, contigua
    while j <= len(C) and L[i+j]!=C[j]:
        j += 1
    
    if i == len(C): # abbiamo esaurito C
        return True
    else:
        return False

print(involucro((),()))

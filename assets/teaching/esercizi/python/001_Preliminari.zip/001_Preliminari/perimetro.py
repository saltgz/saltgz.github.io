l = 4
perimetro = l*4
print(perimetro)

def inversa(s):
    if len(s)==0:
        return ''
    return inversa(s[1:])+s[0]
    #oppure
    #return s[-1]+inversa(s[:-1])

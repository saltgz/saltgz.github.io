#Programma che stampa i primi n numeri dispari.

n = int(input("Inserisci n: "))

for i in range(1,n+1):
    print(i,"° numero dispari: ", 2*i-1, sep='')

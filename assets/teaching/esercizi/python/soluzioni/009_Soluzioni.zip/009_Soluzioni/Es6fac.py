import turtle

def triangolo(lato):
    for i in range(3):
        turtle.forward(lato)
        turtle.left(120)


#triangolo(50)

def Sierpinski(ordine, lato):

    #caso base
    if ordine == 0:
        triangolo(lato)
        return

    #caso ricorsivo: 3 triangoli di ordine -1
    Sierpinski(ordine-1, lato/2)
    turtle.left(60)
    turtle.forward(lato/2)
    turtle.right(60)
    Sierpinski(ordine-1, lato/2)
    turtle.right(60)
    turtle.forward(lato/2)
    turtle.left(60)
    Sierpinski(ordine-1, lato/2)
    turtle.back(lato/2)

Sierpinski(0, 50)
turtle.clear()
turtle.speed(0)
Sierpinski(2, 200)
turtle.clear()
turtle.speed(0)
Sierpinski(3, 200)

"""
turtle.clearscreen()
turtle.goto(-400, -400)
turtle.speed(0)
turtle.clear()
Sierpinski(6, 500)
"""

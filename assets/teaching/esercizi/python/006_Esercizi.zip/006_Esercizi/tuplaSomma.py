def somma(t):
    #verifico che t sia una tupla
    if type(t) != tuple:
        return None

    #verifico che t contenga solo interi
    i = 0
    while i<len(t):
        if type(t[i]) !=int:
            return False
        i += 1

    #Se sono arrivato fin qui, sono tutti interi. Proseguo
    
    #verifico se la tupla soddisfa la proprietà
    
    if len(t) == 0: #caso banale
        return True
    
    #se non banale, scorro tutta la lista e verifico
    i = 1
    acc = t[0]
    while i<len(t):
        if t[i]<=acc:
            return False
        acc += t[i]
        i += 1
    return True

print(somma(3))
print(somma((3,6,9.5,12)))
print(somma(()))
print(somma((1,2,3,4)))
print(somma((1,2,4,8,16)))

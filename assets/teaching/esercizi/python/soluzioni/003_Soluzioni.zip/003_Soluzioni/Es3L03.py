def noleggio(giorni):
    if giorni < 1:
        return 0.0
    if giorni == 1:
        return 45.00
    if giorni == 2:
        return 80.00
    if giorni == 3:
        return 120.00
    if giorni == 4:
        return 160.00
    if giorni > 4:
        return 160.00+40.00*(giorni-4)

print("*** Programma che calcola il costo del noleggio ***")
g = int(input("Inserisci il numero di giorni: "))
costo = noleggio(g)
print("Il costo del noleggio per", g, "giorni è di",costo, "euro")

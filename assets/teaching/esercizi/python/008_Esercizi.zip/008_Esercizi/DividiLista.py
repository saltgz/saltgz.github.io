def dividiLista(A, n):
    if n not in A:
        return A[:], A[:] #NB! Ritorno copie, non puntatori
    minori = []
    maggiori = []
    for e in A:
        if e<=n:
            minori.append(e)
        else:
            maggiori.append(e)
    return minori, maggiori

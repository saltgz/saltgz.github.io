def somma2(t):
    #verifico che t sia una tupla
    if type(t) != tuple:
        return None

    #verifico che t contenga solo interi
    i = 0
    while i<len(t) and type(t[i]) == int:
        i += 1
    if i != len(t): #mi sono fermato prima di scorrere tutta la lista
        return False #vuol dire che un qualche elemento non era int
    
    #verifico se la tupla soddisfa la proprietà
    
    if len(t) == 0: #caso banale
        return True
    
    #se non banale, scorro tutta la lista e verifico
    i = 1
    acc = t[0]
    while i<len(t) and t[i]>acc:
        acc += t[i]
        i += 1
    return i == len(t)
    #se l'ho scorsa tutta, proprietà soddisfatta, altrimenti no

print(somma2(3))
print(somma2((3,6,9.5,12)))
print(somma2(()))
print(somma2((1,2,3,4)))
print(somma2((1,2,4,8,16)))

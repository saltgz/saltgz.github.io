"""Si scriva una funzione confronta(T1, T2) che prende come parametri due stringhe T1 e T2
e restituisce la lista degli i tali che T1[i] e' uno dei caratteri T2[i-1],T2[i],T2[i+1]
(se esistono tutti).
Esempio: confronta(’la mamma in’, ’la nonna ti’’) restituisce la tupla: (0, 1, 2, 7, 8, 9)."""

def confronta (T1,T2):
    """Funzione che restituisce la lista degli i tali che
    T[i] è uguale a uno tra T2[i-1],T2[i],T2[i+1].
    """
    R = ()
    if T1[0] in T2[:2]: #2 escluso (prendo T2[0] e T2[1]
        R += (0,) #tupla di un elemento è (0,)
    for i in range(1, len(T1)): #T1 è una stringa. voglio la sua lunghezza
        if T1[i] in T2[i-1:i+2]: #i+2 e' escluso
            R += (i,)
    return R #devo restituire la tupla accumulata

print(confronta('asca', 'lasca')) #(0, 1, 2, 3)
print(confronta('la mamma in', 'la nonna ti')) #(0, 1, 2, 7, 8, 9)
print(confronta('acca', 'zonzo')) #()

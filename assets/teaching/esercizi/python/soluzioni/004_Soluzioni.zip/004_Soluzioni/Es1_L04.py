def inserisci(t1, t2, n):
    return t1[:n]+t2+t1[n:]

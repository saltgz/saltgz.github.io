import random
numero = random.randint(1,100)
tentativo = int(input("Indovina il numero tra 1 e 100: "))
while tentativo != numero:
    if tentativo < numero:
        print("Troppo piccolo! Prova con un numero più grande")
    elif tentativo > numero:
        print("Troppo grande! Prova con un numero più piccolo")
    tentativo = int(input("Nuovo tentativo: "))
print("Bravo! Era proprio", numero)

def prodottoMatriceScalare(M, s):
    if type(s) not in (int, float, complex):
        return None
    Ms = []
    for r in M:
        new_r = []
        for c in r:
            new_r.append(c*s)
        Ms.append(new_r)
    return Ms
            
            
print(prodottoMatriceScalare([[1,2],[3,4]],2))

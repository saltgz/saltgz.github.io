def valoriUguali(L):

    NewL = []

    if len(L)==0:
        return NewL
    
    num_elementi = 1
    NewL.append(L[0])

    for i in range(1,len(L)):
        if L[i] == L[i-1]:
            num_elementi += 1
        else:
            if num_elementi>=2:
                NewL.append(num_elementi)
                num_elementi = 1
            NewL.append(L[i])

    #Controllo finale
    if num_elementi>=2:
        NewL.append(num_elementi)

    return NewL

A = []
print(A, valoriUguali(A))
A = [1,2,3,4,5]
print(A, valoriUguali(A))
A = ['a','b','c','d']
print(A, valoriUguali(A))
A = ['a','b','b','z','o','o','b','b','b','b','k']
print(A, valoriUguali(A))
A = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
print(len(A))
print(A, valoriUguali(A))
A = [7,7, 8, 8, 5, 5]
print(A, valoriUguali(A))

"""
for i in range(1,len(L)):
    if L[i] == L[i-1]:
        if nuova_sequenza:
            nuova_sequenza = False #se incontrerò un terzo elemento uguale...
            num_elementi = 2
        else:
            num_elementi += 1
    else:
        if !nuova_sequenza: #ho finito la sequenza precedente
            if num_elementi>=2:
                NewL.append(num_elementi)
                num_elementi = 0
        nuova_sequenza = True #elementi diversi, inizio una possibile nuova sequenza
    NewL.append(L[i])            
"""    

    

def ripetisposto(s):
    i = 0
    while i<len(s):
        e = s[i]
        del s[i]
        s[i:i] = [e]*e
        i = i+e

A = [3,0,2,4]
print("Prima: ", A)
ripetisposto(A)
print("Dopo: ", A)
print()
A = [0,0]
print("Prima: ", A)
ripetisposto(A)
print("Dopo: ", A)
print()
A = [1,1,1,1]
print("Prima: ", A)
ripetisposto(A)
print("Dopo: ", A)
print()
A = []
print("Prima: ", A)
ripetisposto(A)
print("Dopo: ", A)

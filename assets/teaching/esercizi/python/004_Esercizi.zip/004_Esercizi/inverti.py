def inverti(s):
    """Funzione che inverte una stringa"""
    s_invert = ''
    for c in s:
        s_invert = c+s_invert
    return s_invert


print(inverti("Lodi"))

def invertiSlice(s):
    return s[::-1]

print(invertiSlice("Lodi"))

def decrescente(a,b,c):
    """Funzione che stampa in ordine decrescente i suoi 3 parametri"""
    if a > b:
        if b > c:
            print(a, b, c)
        elif a > c:
            print(a, c, b)
        else:
            print(c, a, b)
    else: # a <= b
        if c > b:
            print(c, b, a)
        elif c > a:
            print(b, c, a)
        else:
            print(b, a, c)

#Alternativa, usando gli operatori logici
def decrescente2(a, b, c):
    if a >= b and b >= c:
        print(a, b, c)
    elif a >= b and a >= c:
        print(a, c, b)
    elif a >= b:
        print(c, a, b)
    elif b >= c and a >= c:
        print(b, a, c)
    elif b >= c:
        print(b, c, a)
    else:
        print(c, b, a)


print("*** Programma che ordina 3 numeri float ***")
f1 = float(input("Inserisci il primo numero float: "))
f2 = float(input("Inserisci il secondo numero float: "))
f3 = float(input("Inserisci il terzo numero float: "))
print("I tre numeri in ordine decrescente sono: ")
decrescente(f1,f2,f3)
decrescente2(f1,f2,f3)

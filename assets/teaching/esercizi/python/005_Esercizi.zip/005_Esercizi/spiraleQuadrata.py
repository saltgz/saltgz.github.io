import turtle

dist = 10
for i in range(50):
    turtle.forward(dist)
    turtle.right(90)
    dist = dist+5

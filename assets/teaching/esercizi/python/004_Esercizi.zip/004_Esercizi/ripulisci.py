import string
def ripulisci(stringa):
    """rimuove tutti gli spazi bianchi e i segni di interpunzione da una stringa, restituisce la stringa ripulita"""
    stringa_pulita = ''
    for c in stringa:
        if c not in string.punctuation and c not in string.whitespace:
            stringa_pulita = stringa_pulita+c
    return stringa_pulita

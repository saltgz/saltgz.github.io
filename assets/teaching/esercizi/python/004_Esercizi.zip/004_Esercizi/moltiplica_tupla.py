def moltiplica_tupla(t, n):
    """Restituisce una nuova tupla in cui ogni elemento della tupa t è moltiplicato per n"""
    t_out = () #la nuova tupla, per ora vuota
    for e in t:
        """nella nuova tupla, inserisco come nuovo elemento
        ogni elemento della tupla presa come parametro,
        moltiplicato per n
        """
        t_out = t_out + (e*n,)
    return t_out
    

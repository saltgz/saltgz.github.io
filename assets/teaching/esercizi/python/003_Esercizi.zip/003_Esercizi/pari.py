def isPari(n):
    """Funzione che dice se un numero è pari o no"""
    if n % 2 == 0: #un numero è pari se diviso per due non da resto
        return True
    else:
        return False

#ancora più sintetico:
def isPari2(n):
    return n % 2 == 0

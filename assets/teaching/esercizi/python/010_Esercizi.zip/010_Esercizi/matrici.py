

def stampaMatrice(M):       
    for riga in M:
        for e in riga:
            print(e, end='\t')
        print() #a capo dopo ogni riga

def molt_liste(U,V):
    if len(U)==len(V):
        pr_sc = 0
        for i in range(len(V)):
            pr_sc = pr_sc + (U[i]*V[i])
        return pr_sc
    else:
        return None

def molt_liste_2(U,V):
    if len(U)==len(V):
        pr_sc = 0
        for eu, ev in zip(U, V): #lo posso fare perche' hanno la stessa len
            pr_sc = pr_sc + eu*ev
        return pr_sc
    else:
        return None

def righe(M):
    return len(M)

def colonne(M):
    return len(M[0])

def sono_matr_molt(M,N):
    return colonne(M) == righe(N)

def trasposta(M):
    MT = []
    r = righe(M)
    if r == 0: #vuota
        return MT
    else:
        c = colonne(M)
        for i in range(c): #ciclo sulle colonne
            col = [] #i-ma colonna
            for j in range(r): #ciclo sulle righe
                col.append(M[j][i])
            #ora in col ho la i-ma colonna, che diventa l'i-ma riga
            MT.append(col)
        return MT

def molt_mat(A,B):
    if sono_matr_molt(A,B): # se posso eseguire la molt
        AB = [] #prodotto
        BT = trasposta(B) #trasposta di B
        for i in range(righe(A)): #righe di A (e quindi di AB)
          riga = [] #i-ma riga di AB
          for j in range(righe(BT)):#righe di BT (= col di B e AB)
                ij = molt_liste(A[i],BT[j]) #prodotto scalare
                riga.append(ij) #inseriesco elemento nella riga
          AB.append(riga) #inserisco la riga nel risultato
        return AB
    else:
        print("Matrici non moltiplicabili")
        return None

if __name__ == "__main__":
    A = [[1, 2, 3], [4, 5, 6]]
    B = [[2, 1, 3, 1], [1, 2, 3, 4], [4, 1, 2, 3]]
    AB = molt_mat(A,B)
    stampaMatrice(A)
    print(" moltiplicata per ")
    stampaMatrice(B)
    print("risulta")
    stampaMatrice(AB)
    print()
    print()
    print()

    V = [[2, 4, 6]]
    VB = molt_mat(V, B)
    stampaMatrice(V)
    print(" moltiplicata per ")
    stampaMatrice(B)
    print("risulta")
    stampaMatrice(VB)
    print()
    print("Invece se cambio l'ordine")
    BV = molt_mat(B, V) #impossibile
    print()
    print()
    print()
    
    C = [[1], [3], [5]]
    AC = molt_mat(A,C)
    VC = molt_mat(V,C)
    stampaMatrice(A)
    print(" moltiplicata per ")
    stampaMatrice(C)
    print("risulta")
    stampaMatrice(AC)
    print()
    print()
    print()

    stampaMatrice(V)
    print(" moltiplicata per ")
    stampaMatrice(C)
    print("risulta")
    stampaMatrice(VC)
    print()
    print()
    print()

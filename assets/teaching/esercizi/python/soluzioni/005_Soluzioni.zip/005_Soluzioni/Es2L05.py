def MCD(a,b):
    """Funzione che calcola il massimo comun divisore tra a e b"""

    if b == 0:
        return a
    if a == 0:
        return b
    
    if a<b:
        minore = a
    else:
        minore = b

    #scorro tutti i numeri dal minore dei due fino a 1
    for i in range(minore, 0, -1):
        if (a % i == 0) and (b % i == 0): #se entrambi sono divisibili per i...
            return i #... allora i e' il loro massimo comun divisore

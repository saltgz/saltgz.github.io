def minimoRic(s):
    if len(s)==0:
        return None
    if len(s)==1:
        return s[0]
    m = minimoRic(s[1:])
    if s[0] < m:
        return s[0]
    else:
        return m

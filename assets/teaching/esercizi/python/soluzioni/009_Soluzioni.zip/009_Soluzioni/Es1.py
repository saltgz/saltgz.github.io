""" Programma ricorsivo che calcola
la somma dei primi n numeri dispari"""

#Caso base: la somma dei primi 0 numeri dispari e' 0
#Ipotesi induttiva: possiedo la somma dei primi n-1 numeri dispari (sommaDispari(n-1))
#Soluzione al problema generale:
# - possiedo la somma dei primi n-1 numeri dispari
# - sommo l'n-simo numero dispari (che è 2*n-1)
# - ottengo così la somma dei primi n numeri dispari

def sommaDispari(n):
    if n == 0:
        return 0
    return sommaDispari(n-1)+(2*n-1)
    

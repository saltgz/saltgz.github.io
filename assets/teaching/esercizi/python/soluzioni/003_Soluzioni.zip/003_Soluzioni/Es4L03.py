"""
\hline 
 & Valore.. & ...da dividere per & \multicolumn{2}{c|}{risultati utili} \\ 
\hline 
  &   &  &  Quoziente intero & Resto \\ 
\hline 
1 & $x$ (anno) & 100 & $b$ & $c$ \\ 
\hline 
2 & $5b+c$ & 19 & - & $a$ \\ 
\hline 
3 & $3(b+25)$ & 4 & $r$ & $s$ \\ 
\hline 
4 & $8(b+11)$ & 25 & $t$ & - \\ 
\hline 
5 & $19a+r-t$ & 30 & - & $h$ \\ 
\hline 
6 & $a+11h$ & 319 & $g$ & - \\ 
\hline 
7 & $60(5-s)+c$ & 4 & $j$ & $k$ \\ 
\hline 
8 & $2j-k-h+g$ & 7 & - & $m$ \\ 
\hline 
9 & $h-g+m+110$ & 30 & $n$ (mese) & $q$ \\ 
\hline 
10 & $q+5-n$ & 32 & - & $p$ (giorno) \\ 
\hline
"""

def pasqua(x):
    b = x // 100
    c = x % 100
    due = 5*b+c
    a = due % 19
    tre = 3*(b+25)
    r = tre // 4
    s = tre % 4
    quattro = 8*(b+11)
    t = quattro // 25
    cinque = 19*a+r-t
    h = cinque % 30
    sei = a+11*h
    g = sei // 319
    sette = 60*(5-s)+c
    j = sette // 4
    k = sette % 4
    otto = 2*j-k-h+g
    m = otto % 7
    nove = h-g+m+110
    n = nove // 30
    q = nove % 30
    dieci = q+5-n
    p = dieci % 32
    return p, n


def pasquaDivMod(x):
    """
    Questa versione usa la funzione divmod
    di Python. Effettua alcuni calcoli inutili
    ma è più elegante e traduce in maniera
    chiara la tabella del testo
    """
    # _ è una variabile da ignorare
    b,c = divmod(x,100)
    _,a = divmod(5*b+c,19)
    r,s = divmod(3*(b+25),4)
    t,_ = divmod(8*(b+11),25)
    _,h = divmod(19*a+r-t,30)
    g,_ = divmod(a+11*h,319)
    j,k = divmod(60*(5-s)+c,4)
    _,m = divmod(2*j-k-h+g,7)
    n,q = divmod(h-g+m+110,30)
    _,p = divmod(q+5-n,32)
    return p, n


def pasquaDivModRipulita(x):
    """
    Dalla precedente possiamo rimuovere i calcoli inutili
    (perdendo però in eleganza)
    """
    b,c = divmod(x,100)
    a = (5*b+c)%19
    r,s = divmod(3*(b+25),4)
    t = (8*(b+11))//25
    h = (19*a+r-t)%30
    g = (a+11*h)//319
    j,k = divmod(60*(5-s)+c,4)
    m = (2*j-k-h+g)%7
    n,q = divmod(h-g+m+110,30)
    p = (q+5-n)%32
    return p, n


print("*** Programma che calcola giorno e mese della pasqua***")
anno = int(input("Inserisci l'anno: "))
giorno, mese = pasqua(anno)
print("Nell'anno", anno, "paqua cade il",giorno,"/",mese)
print()
print("Con seconda funzione: ", pasquaDivMod(anno))
print("Con terza funzione: ", pasquaDivModRipulita(anno))

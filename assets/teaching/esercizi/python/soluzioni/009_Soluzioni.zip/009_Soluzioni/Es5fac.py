import turtle, math

def quadrato(lato):
    for i in range(4):
        turtle.forward(lato)
        turtle.left(90)
    
def alberoPitagorico(livello, lato = 100):
    if livello > 0:
        quadrato(lato) 
    if livello>1:
        #teorema di pitagora per il lato dei quadratini
        n_lato = (lato/2)*math.sqrt(2)
        #raggiungo angolo in alto a sinistra
        turtle.left(90)
        turtle.forward(lato)
        #mi inclino per disegnare sottoalbero di sinistra
        turtle.right(45)
        #disegno il sottoalbero di sinistra, con n_lato
        alberoPitagorico(livello-1,n_lato)
        #sono tornato al quadrato principale
        #raggiungo vertice triangolo
        turtle.forward(n_lato)
        #mi preparo a disegnare il sottoalbero di destra
        turtle.right(90)
        #disegno il sottoalbero di sinistra, con n_lato
        alberoPitagorico(livello-1,n_lato)
        #raggiungo angolino in alto a destra e mi rioriento
        turtle.forward(n_lato)
        turtle.left(45)
        #torno alla posizione di partenza ripercorrendo
        #il lato superiore e quello sinistro
        turtle.backward(lato)
        turtle.right(90)
        turtle.forward(lato)
        turtle.left(90)

turtle.speed(0)
turtle.pensize(3)
alberoPitagorico(5)

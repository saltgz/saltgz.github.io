print("***Gestione voti studente***")
print("- Inserire un voto (1)")
print("- Visualizzare tutti i voti (2)")
print("- Stampare la media dei voti (3)")
print("- Terminare il programma (0)")
voti = ()
scelta = int(input("Scelta: "))
while scelta != 0:
    if scelta == 1:
        voti += (eval(input("Inserisci un voto: ")),)
    elif scelta == 2:
        print(voti)
    elif scelta == 3:
        if len(voti)>0:
            acc = 0
            for v in voti:
                acc += v
            print(acc/len(voti))
        else:
            print("Nessun voto su cui calcolare la media")
    else:
        print("Scelta non valida")
    print()
    scelta = int(input("Scelta: "))

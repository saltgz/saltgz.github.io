#FUNZIONI CON ERRORI

def interi(t):
    """Verifica che t sia una tupla di soli interi"""
    for i in range(len(t)):
        if type(t[i])==int:
            return True

def somma(t):
    """Funzione che verifica che ogni elemento della tupla
    eccetto il primo sia maggiore della somma dei precedenti"""
    if not interi(t):
        return False
    somma = t[0] 
    i = 0 
    while i < len(t):
        if t[i] <= somma:
            return False
        somma += t[i]
        i += 1
        return True


print(somma((1,2,4))) #True    
      

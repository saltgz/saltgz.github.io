"""Date due tuple di naturali tutti distinti A e B, diciamo che costituiscono un involucro
se una delle due compare come sottosequenza contigua dentro l’altra, con almeno un elemento
a sinistra e almeno un elemento a destra che non le appartengono. Esempio: (0,1,2,3,11,16) e
(1,2,3) costituiscono un involucro; (1,2,3) e (1,2,3,11) non lo sono.
Se una delle due e' vuota, l’altra deve avere almeno due elementi (la sequenza vuota “sta nel mezzo” ai due elementi,
uno a sinistra, uno a destra).
Si scriva una funzione Python
involucro(A,B) che, presi come parametri due tuple di naturali restituisce True sse esse costituiscono un involucro.
Provare infine la funzione chiedendo in input due tuple.
"""


def involucro(A,B):
    #se chiedo qui input, sovrascrivo i valori passati come parametri

    if len(A)==0 or len(B)==0: # == per confronto
        if (len(A)==0 and len(B)>=2) or (len(A)>=2 and len(B)==0):
            return True
        return False #questo return va dentro all'if, voglio ritornare solo se una delle due è vuota. 
        #Se lo metto fuori, il return viene eseguito sempre, indipendentemente dalle condizioni.

    if len(A)>len(B):
        return inv_aux(B,A) #tupla lunga dopo
    else:
        return inv_aux(A,B)

    
def inv_aux(C,L): # L e’ la tupla lunga e C quella corta; non sono vuote
    i = 1 #secondo elemento è 1

    while i < len(L)-len(C) and L[i] != C[0]: #i < per lasciare un elemento. Devo continuare se non ho ancora trovato C[0], quindi !=
        i += 1
    if i == len(L)-len(C): # se C[0] non e ’ in L (ad un indice sufficientemente "piccolo" per lasciare un elemento a destra di C), restituisci False
        return False

    j = 1 #secondo elemento e' 1
    while j < len(C) and L[i+j] == C[j]: #j < per non fare overflow. Devo continuare se sto trovando elementi uguali della sottosequenza, quindi ==
        j += 1
    
    if j == len(C): #e' j che scorre C!
        return True
    else:
        return False

#ALTERNATIVA: Funzione ausiliaria riscritta, più sintetica
def inv_aux2(C,L) : #L e' la tupla lunga e C quella corta; non sono vuote
    i = 1 #cerchiamo in L, se c'e', l'inizio di C, partendo dal secondo elemento
# per lasciare un elemento a sinistra
    while i < len(L)-len(C):
        if L[i]==C[0]:
            if C[1:len(C)]==L[i+1:i+len(C)]:
                return True   
        i += 1
    return False


#per velocizzare le prove mi risparmio l'input
print(involucro( (0,1,2,3,11,16), (1,2,3) )) #True
print(involucro( (1,2,3), (1,2,3,11))) #False
print(involucro( (1,2), () ))#True
print(involucro( (), (1,))) #False


#Input va chiesto qui
#Mancano parentesi di chiusura
#tuple non va bene: input ritorna una stringa, che viene convertita
#in tupla carattere per carattere. Usare eval
A = eval(input("Inserisci una tupla: ")) 
B = eval(input("Inserisci una tupla: "))
print(A,B) #verifico se l'input è corretto
print(involucro(A,B))





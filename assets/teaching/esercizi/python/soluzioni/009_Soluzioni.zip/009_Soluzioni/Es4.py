import Es1Lab09, copy, matrici

def sottomatrice(M, r, c):
    """Restituisce una nuova matrice in cui sono state eliminate la riga r e la colonna c"""
    SM = copy.deepcopy(M)
    del SM[r] #cancello la riga
    for riga in SM:
        #per ogni altra riga, elimino l'elemento della colonna
        del riga[c]
    return SM

def determinante(M):
    if not Es1Lab09.matrice_quadrata(M):
        print("Non è una matrice quadrata")
        return None
    if matrici.righe(M) == 0:
        print("Matrice vuota")
        return None
    if M == [[]]:
        print("Matrice 'patologica' 1x0")
        return None
    if matrici.righe(M)==1 and matrici.colonne(M)==1:
        return M[0][0] #per def il determinante e' l'unico elemento
    else:
        det = 0
        i = 0 #una riga a caso
        for j in range(0,matrici.colonne(M)): #j scorre le colonne
            det += ((-1)**(i+j))*M[i][j]*determinante(sottomatrice(M,i,j))
        return det

M0 = [[3]]
print("determinante", M0, "vale", determinante(M0)) #3
print()
M1 = [[-1, 3], [4, 7]]
print("determinante", M1, "vale", determinante(M1)) #-19
print()
M1 = [[5, -2], [7, -1]]
print("determinante", M1, "vale", determinante(M1)) #9
print()
M1 = [[6, 2], [-3, -5]]
print("determinante", M1, "vale", determinante(M1)) #-24
print()
M1 = [[3, 1, 5],[9, -2, 4],[1, -1, 3]]
print("determinante", M1, "vale", determinante(M1)) #-64
print()
M2 = [[3, 2, 1, -5], [-1, 2, 1, -3], [5, -1, 2, 4], [3, 1, -1, 5]] #222
print("determinante", M2, "vale", determinante(M2)) 


s = "Python"
n = 10
print(s*n)

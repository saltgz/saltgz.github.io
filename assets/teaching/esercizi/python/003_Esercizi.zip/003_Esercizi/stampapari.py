import pari

numero = int(input("Inserisci un numero intero: "))
if pari.isPari(numero):
    print("Il numero è pari")
else:
    print("Il numero è dispari")

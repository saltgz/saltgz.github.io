#FUNZIONE CON ERRORI

def crescente(t):
    """Funzione che prende come parametro una tupla t
    e restituisce True se tutti i valroi sono in ordine strettamente crescente,
    False altrimenti"""
    for i in range(len(t)):
        if t[i+1]>t[i]:
            return True
    return False


print(crescente((1,2,2,4))) #Atteso: False

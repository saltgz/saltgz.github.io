import string #va importato

def posizione(c,s): #nessun errore
    """Funzione che ritorna l'indice del carattere c nella stringa s,
    (l'indice della prima volta in cui compare c, se c e' presente piu' volte)
    o None se non è presente"""
    if c not in s:
        return None
    for i in range(len(s)):
        if c == s[i]:
            return i

def cesare(s):
    s = s.lower() #il metodo si chiama lower()
    #e la coastante string.ascii_lowercase
    cifrata = ''
    for c in s:
        if c not in string.ascii_lowercase: #se NON e' un alfabetico, mantengo invariato
            cifrata += c
        else: #c è un carattere, va sostituito con il suo cifrato
            p = posizione(c, string.ascii_lowercase)
            #le lettere dell'alfabeto inglese (e len(ascii_lowercase)) sono 26
            pc = (p + 13) % 26 #operatore % lega di piu' di +, servono parentesi
            cc = string.ascii_lowercase[pc] #pc e' l'indice di c, cifrato, nell'alfabeto
            cifrata += cc #devo concatenare il cifrato
    return cifrata


print(posizione('e', "Michael")) #5
print(posizione('m', "Lodi")) #None
print()

print(cesare("Michael"))  #zvpunry
print(cesare(cesare("giulio"))) #giulio
print(cesare("Anche tu, Bruto, figlio mio!")) #napur gh, oehgb, svtyvb zvb!
print(cesare("napur gh, oehgb, svtyvb zvb!")) #anche tu, bruto, figlio mio!

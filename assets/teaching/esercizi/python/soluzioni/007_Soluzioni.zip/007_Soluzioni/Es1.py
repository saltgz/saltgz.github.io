#https://it.wikipedia.org/wiki/Metodo_della_bisezione


print("Caro utente, pensa un numero da 1 a 100, e io proverò a indovinarlo")

indovinato = False #flag booleano che varrà True quando ho indovinato

tentativi = 0

#intervallo in cui produrre un tentativo
i = 1
f = 100

while not indovinato:
    #provo con un numero a metà dell'intervallo
    tentativo = (i+f)//2
    tentativi += 1
    r = input("Ho indovinato? Il numero a cui hai pensato è "+str(tentativo)+" ?: ")
    r = r.lower()
    if 'piccolo' in r:
        #devo provare con un numero più grande, tengo la metà superiore dell'intervallo
        i = tentativo+1
    elif 'grande' in r:
        #devo provare con un numero più piccolo, tengo la metà inferiore dell'intervallo
        f = tentativo-1
    elif 'indovinato' in r:
        indovinato = True
        print("Sono stato molto bravo! Ho indovinato in", tentativi, "tentativi")
    else:
        r = input("Ho indovinato? Il numero a cui hai pensato è "+str(tentativo)+" ?: ")
    
        

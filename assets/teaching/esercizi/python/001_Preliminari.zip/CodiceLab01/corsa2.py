distanza = 10
secondi = 42*60+42
kminmiglio = 1.61

kmALminuto = distanza/(secondi/60)
kmh = distanza/(secondi/(60*60))
migliaALminuto = (distanza/kminmiglio)/(secondi/60)
migliaorarie = (distanza/kminmiglio)/(secondi/3600)

print("km/min", kmALminuto)
print("km/h", kmh)
print("mpm", migliaALminuto)
print("mph", migliaorarie)

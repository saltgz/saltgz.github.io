def palindroma(s):
    if len(s)==0:
        return True

    return palindroma(s[1:-1]) and s[0]==s[-1]

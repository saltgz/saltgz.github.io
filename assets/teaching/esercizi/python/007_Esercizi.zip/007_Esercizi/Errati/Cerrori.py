#FUNZIONI CON ERRORI

#Scrivere una funzione che restituisce una tupla contenente tutti i divisori propri
#(quindi n escluso) di 
#un numero naturale n preso come parametro.
def divisoripropri(n):
    """Restituisce una tupla di tutti i divisori propri di n"""
    div=()
    for i in range(n):
        if n%i=0:
            div=div+i
    print(div)
    
#Un numero è perfetto se il numero è uguale alla somma dei divisori propri.
#scrivere una funzione che prende come parametro un numero naturale n, stampa
#e restituisce True se il numero è un numero perfetto, False altrimenti.


def numperfetto(n):
    """Restituisce True se n è un numero perfetto,
    cioè se è uguale alla somma dei suoi divisori propri,
    False altrimenti."""
    div=divisoripropri(n)
    sommaDiv=0
    for el in div:
        sommaDiv+=el
        if sommaDiv == n:
            print(n, " è un numero perfetto!")
            return True
        else:
            print(n, " non è un numero perfetto!")
            return False

"""
I primi numeri perfetti sono
6     = 1 + 2 + 3
28    = 1 + 2 + 4 + 7 + 14
496
8128
33550336
"""

#False
print(numperfetto(3))

#True
print(numperfetto(6))
print(numperfetto(28))
print(numperfetto(496))
print(numperfetto(8128))
print(numperfetto(33550336))



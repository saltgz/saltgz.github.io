import primogrado #il nome del file in cui avevamo scritto la funzione

print("Programma che risolve le equazioni ax+b=0")
print()
a = float(input("scrivi il valore di a: "))
b = float(input("scrivi il valore di b: "))
print(primogrado.equazione_primo_grado(a,b))

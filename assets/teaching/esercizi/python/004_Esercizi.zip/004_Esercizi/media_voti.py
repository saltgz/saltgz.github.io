def media(voti):
    """Calcola la media dei voti presenti nella tupla passata come parametro"""
    somma = 0
    for voto in voti:
        somma = somma + voto
    if len(voti)>0:
        media = somma/len(voti)
        return media
    else:
        print("Nessun voto inserito")
        return None

miei_voti = eval(input("Inserisci i voti separati da virgole: "))
print("Media:", media(miei_voti))

import string
def cons_n_voc(s):
    vocali = "aeiouAEIOU"
    n_vocali = 0
    print("Consonanti: ")
    for l in s:
        if l in vocali:
            n_vocali = n_vocali + 1
        elif l in string.ascii_letters: #so già che non è una vocale
            print(l)
    print("Numero di vocali:", n_vocali)

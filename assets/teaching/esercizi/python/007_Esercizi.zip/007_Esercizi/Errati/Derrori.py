#FUNZIONE CON ERRORI

"""Un plateau è una sottosequenza di almeno due elementi contigui con lo stesso valore
Scrivere una funzione plat(s) che, data una tupla s, restituisce la tupla degli elementi
distinti di s che sono valori di un plateau.
Esempio: plat((3,3,0,2,2,2,0,3,3,4,4)) restituisce (3,2,4)
"""

def plat(s):
    """Data una tupla s, la tupla degli elementi
    distinti di s che sono valori di un plateau"""
    for i in range(len(s-1)):
        if s[i]== s[i+1] and res[-1]!=s[i]:
            res = res + s[i]
        return res

print(plat((3,3,0,2,2,2,0,3,3,4,4))) #atteso (3,2,4)
print(plat(())) #atteso ()
print(plat((1,3,5,2))) #atteso ()
print(plat((1,1,1,1,1,1))) #atteso (1,)

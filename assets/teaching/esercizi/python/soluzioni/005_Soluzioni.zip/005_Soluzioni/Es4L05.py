import turtle, Es3L05

def stellina(n):
    if n>=7:
        for i in range(n): #ho n lati
            turtle.forward(100)
            turtle.right((360/n)*Es3L05.nondivisore(n)) 

#Funzione di prova (non necessaria per la soluzione dell'esercizio)
def stampatutte():
    from time import sleep
    turtle.clearscreen()
    lati = 7
    while True:
        turtle.write(lati)
        stellina(lati)
        lati+=1
        sleep(1) #aspetto un secondo
        turtle.clearscreen()
    

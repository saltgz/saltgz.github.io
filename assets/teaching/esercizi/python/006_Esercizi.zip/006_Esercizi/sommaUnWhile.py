def somma3(t):
    if type(t) == tuple: #else return None
        i = 0
        somma = 0
        while i < len(t):
            if (type(t[i]) != int) or (i > 0 and t[i] <= somma):
                return False
            somma += t[i]
            i += 1
        return True

print(somma((-1,0)))

a = 7
b = 20

tmp = a
a = b
b = tmp

print("a vale", a)
print("b vale", b)

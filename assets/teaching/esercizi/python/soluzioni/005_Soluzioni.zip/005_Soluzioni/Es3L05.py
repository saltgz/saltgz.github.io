import Es2L05
def nondivisore(n):
    if n>2:
       for c in range(2,n):
           if Es2L05.MCD(n,c) == 1:
               return c

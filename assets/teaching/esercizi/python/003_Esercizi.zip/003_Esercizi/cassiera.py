import biglietto

nome = input("Come si chiama? ")
eta = int(input("Quanti anni ha? "))

print("Salve", nome)
print("La sua tipologia di biglietto è: ", biglietto.sconto(eta))

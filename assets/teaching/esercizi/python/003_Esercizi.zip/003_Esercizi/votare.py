risposta = input("Quanti anni hai? ")
if (risposta < 18):
    print("Non puoi ancora votare!")
else:
    print("Vota con giudizio")

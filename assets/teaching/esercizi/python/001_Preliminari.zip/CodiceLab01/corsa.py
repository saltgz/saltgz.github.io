s=42*60+42
k=10
m=k/1.61
mps=m/s
mpm=mps*60
mph=mpm*60
kps=k/s
kpm=kps*60
kph=kpm*60
print('Hai corso', kpm, 'kilometri al minuto')
print('Hai corso', kph, 'kilometri orari')
print('Hai corso', mpm, 'miglia al minuto')
print('Hai corso', mph, 'miglia orarie')

def tabellina(n):
    for i in range(0,11):
        print(n,"x",i,"=",n*i,sep='')

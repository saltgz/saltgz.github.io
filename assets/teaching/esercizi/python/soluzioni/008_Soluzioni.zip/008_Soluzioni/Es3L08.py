def ripetis(s):
    res = []
    for e in s:
        res += [e]*e
    return res

#alternativa
def ripetis2(s):
    res = []
    for e in s:
        for i in range(e):
            res.append(e)
    return res

print(ripetis([3,0,2,4]))
print(ripetis2([3,0,2,4]))

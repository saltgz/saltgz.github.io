def Floyd(n):
    primo_elemento = 1
    for riga in range(1,n+1): #for per ogni "riga" del triangolo (da 1 a n)
        primo_elemento_succ = primo_elemento+riga #primo elemento riga successiva
        print(tuple(range(primo_elemento, primo_elemento_succ))) #ricorda: ultimo elemento escluso
        primo_elemento = primo_elemento_succ #aggiorno prima di passare alla riga successiva

"""funzione ricorsiva che prende come parametri una tupla e un numero n,
e restituisce una nuova tupla
in cui ogni elemento è stato moltiplicato per n"""

#caso base: se la tupla è vuota, lo sarà anche il prodotto
#ipotesi magica: ho la tupla già moltiplicata dal secondo elemento
#soluzione generale: alla tupla già moltiplicata dal secondo elemento
#aggiungo in testa il primo elemento moltiplicato per n.

def moltiplica_tupla(t, n):
    if len(t)==0:
        return ()
    else:
        return (t[0]*n,)+moltiplica_tupla(t[1:],n)

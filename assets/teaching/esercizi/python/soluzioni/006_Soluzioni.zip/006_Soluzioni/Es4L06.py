def ciclo(A,k):
    #Sequenza vuota, banalmente vero
    if len(A) == 0:
        return True

    """Potrei controllare anche che la lunghezza della stringa sia
    #un multiplo di k, e il caso particolare della sequenza con un solo elemento"""

    #scorro tutti gli elementi, facendo attenzione a fermarmi al penultimo
    i = 0
    while i<len(A)-1:
        if A[i+1] != (A[i]+1)%k:
            return False
        i+=1

    #controllo se il primo è il successore dell'ultimo
    return A[0] == (A[i]+1)%k


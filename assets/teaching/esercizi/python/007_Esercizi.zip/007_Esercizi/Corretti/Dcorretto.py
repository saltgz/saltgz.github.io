#FUNZIONE CORRETTA

"""Un plateau è una sottosequenza di almeno due elementi contigui con lo stesso valore
Scrivere una funzione plat(s) che, data una tupla s, restituisce la tupla degli elementi
distinti di s che sono valori di un plateau.
Esempio: plat((3,3,0,2,2,2,0,3,3,4,4)) restituisce (3,2,4)
"""

def plat(s):
    """Data una tupla s, la tupla degli elementi
    distinti di s che sono valori di un plateau"""
    res = () #devo inizializzare alla tupla vuota l'accumulatore
    for i in range(len(s)-1): #s-1 non ha senso. Devo arrivare a len(s) a cui tolgo 1 perché accedo a i+1 nel corpo
        if s[i]==s[i+1] and s[i] not in res: #perché la tupla sia di elementi distinti, devo controllare di non aver messo già s[i]
            res = res + (s[i],) #non posso sommare tuple e interi. devo rendere s[i] all'interno di una tupla di lunghezza 1
    return res #devo ritornare res fuori dal ciclo, solo quando ho scorso tutta la tupla s

print(plat((3,3,0,2,2,2,0,3,3,4,4))) #atteso (3,2,4)
print(plat(())) #atteso ()
print(plat((1,3,5,2))) #atteso ()
print(plat((1,1,1,1,1,1))) #atteso (1,)

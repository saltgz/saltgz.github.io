def Collatz(n):
    if n<1:
        print("n deve essere positivo")
    else:
        while n != 1:
            print(n, end=' ') #stampo senza andare a capo
            if n % 2 == 0: #pari
                n = n//2
            else: #dispari
                n = 3*n + 1
        print(n) #stampo l'1. 

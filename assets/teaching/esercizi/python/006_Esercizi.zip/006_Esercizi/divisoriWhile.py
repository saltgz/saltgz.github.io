def divisori(x):
    i=1
    div=()
    while i<=x :
        if x%i==0:
            div=div+(i,)
        i+=1
    return div

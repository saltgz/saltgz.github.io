import turtle

def albero(livello):
    if livello < 1:
        return
    if livello == 1: #caso base
        turtle.forward(100)
        turtle.backward(100)
    else: #caso ricorsivo
        turtle.forward(100) #disegno il tronco
        turtle.left(30)     #mi giro a sinistra
        albero(livello-1)   #disegno l'albero a sinistra
        turtle.right(30)    #mi rimetto al centro
        turtle.right(30)    #mi giro a destra
        albero(livello-1)   #disegno l'albero a destra
        turtle.left(30)     #mi rimetto al centro
        turtle.backward(100)#ripercorro indietro il tronco

#Programma di prova
turtle.setheading(90) #guardo in su
turtle.speed(0) #velocissimo
turtle.pensize(5)
albero(4) #esempio di chiamata della funzione


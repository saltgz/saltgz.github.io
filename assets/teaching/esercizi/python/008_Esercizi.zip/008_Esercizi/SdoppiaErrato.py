def sdoppiaErrato(A):
    i = 1
    for i in range(1,len(A)):
        if A[i] == A[i-1]:
            del A[i]

A = [1,2,2,-1,0,0,2,2,2,2,3]
print("old: ", A)
sdoppiaErrato(A)
# errore Traceback (most recent call last):
# File "SdoppiaErrato.py", line 11, in <module>
#    sdoppiaErrato(A)
#  File "SdoppiaErrato.py", line 5, in sdoppiaErrato
#    if A[i] == A[i-1]:
# IndexError: list index out of range

import math
def radicedie():
    """Funzione che stampa la radice quadrata del numero di Nepero"""
    print(math.sqrt(math.e))

from matrici import *
from math import inf

def verifica(M, n):
    somma = 0    
    i = 0
    while i<righe(M):
        j = 0
        while j<colonne(M):
            somma += M[i][j]
            if somma > n:
                return (i,j)
            j+=1
        i+=1
    return (inf,inf)

A = [[1,2,3],
     [4,5,6],
     [7,8,9]]

print(verifica(A,14)) #atteso: (1,1)
print(verifica(A,-3)) #atteso: (0,0)
print(verifica(A,1)) #atteso: (0,1)
print(verifica(A,44)) #atteso: (2,2)
print(verifica(A,45)) #atteso: (inf,inf)
print(verifica(A,46)) #atteso: (inf,inf)

B = [[7,4,1],
     [5,2,9],
     [1,3,4]]

print(verifica(B,5)) # 0,0
print(verifica(B,7)) # 0,1
print(verifica(B,20)) #1,2
print(verifica(B,37)) #inf,inf

C = [[1]]

print(verifica(C,2)) #inf,inf
print(verifica(C,0)) #(0,0)

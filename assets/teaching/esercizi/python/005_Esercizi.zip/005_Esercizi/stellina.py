import turtle

for i in range(5): #ho 5 lati
    turtle.forward(100)
    #come un pentagono, ma l'angolazione è doppia perché "salto" un vertice
    turtle.right(144) 

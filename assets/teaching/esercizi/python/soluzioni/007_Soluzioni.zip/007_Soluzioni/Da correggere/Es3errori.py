#CODICE ERRATO

def posizione(c,s):
    """Funzione che ritorna l'indice del carattere c nella stringa s,
    (l'indice della prima volta in cui compare c, se c e' presente piu' volte)
    o None se non è presente"""
    if c not in s:
        return None
    for i in range(len(s)):
        if c == s[i]:
            return i

def cesare(s):
    """Funzione che modifica la stringa s sostituendo a ogni lettera
    la lettera che si trova 13 posizioni piu' avanti
    nell'alfabeto. Esempio 'b' diventa 'o', 'm' diventa 'z', 'n' diventa 'a'.
    Lavoro solo con alfabeto minuscolo, convertento eventualmente s.
    Tutti gli altri caratteri (cifre, punteggiatura, spazi) non vengono modificati.
    """
    s = s.tolower() #converto la stringa tutta in minuscolo
    cifrata = ''
    for c in s:
        if c in string.ascii_lower: #mantengo spazi e punteggiatura invariati
            cifrata += c
        else: #c è un carattere, va sostituito con il suo cifrato
            p = posizione(c, string.ascii_lower)
            pc = p + 13 % 21
            cc = string.ascii_lower[p]
            cifrata += c
    return cifrata

print(posizione('e', "Michael")) #5
print(posizione('m', "Lodi")) #None
print()

print(cesare("Michael"))  #zvpunry
print(cesare(cesare("giulio"))) #giulio
print(cesare("Anche tu, Bruto, figlio mio!")) #napur gh, oehgb, svtyvb zvb!
print(cesare("napur gh, oehgb, svtyvb zvb!")) #anche tu, bruto, figlio mio!

def calcolaCapitaleFinale(C, r, n, t):
    """ Funzione che calcola il capitale finale di un investimento.
    C = capitale iniziale,
    r = tasso di interesse decimale
    n = numero di calcoli dell'interesse
    t = numero di anni
    """
    M = C*(1+(r/n))**(n*t)
    return M

Mf = calcolaCapitaleFinale(10000, 0.08, 12, 2)
print("Capitale finale per investimento di 10.000, calcolo mensile, tasso 8%, per 2 anni: ", Mf)

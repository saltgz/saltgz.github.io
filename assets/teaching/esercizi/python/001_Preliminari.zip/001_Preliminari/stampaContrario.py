s = "lodi"
s_contrario = s[3]+s[2]+s[1]+s[0]
print(s_contrario)

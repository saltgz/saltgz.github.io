import math
def radiceSommaQuadrati(a,b):
    """ Funzione che calcola la somma dei quadrati di due numeri presi come parametri"""
    i=a**2+b**2
    i=math.sqrt(i)
    return i 
	
x = 2
y = 3
distanza = radiceSommaQuadrati(x,y)
print("La distanza del punto (",x,", ",y,") dall'origine (0,0) è ", distanza, sep='')

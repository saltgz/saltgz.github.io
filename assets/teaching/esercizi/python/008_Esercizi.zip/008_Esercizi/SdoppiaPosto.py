def sdoppiaSulPosto(A):
    if type(A)!=list:
        return None

    if len(A)==0:
        return None

    i = 1
    while i<len(A):
        if A[i] == A[i-1]:
            del A[i] #del accorcia A; non cambio i
        else:
            i+=1

A = [1,2,2,-1,0,0,2,2,2,2,3]
print("old: ", A)
sdoppiaSulPosto(A)
print("new: ", A)

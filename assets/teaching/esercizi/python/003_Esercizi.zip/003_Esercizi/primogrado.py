import math
def equazione_primo_grado(a,b):
    if (a==0) and (b==0): #condizione soluzione indeterminata
        print("Equazione indeterminata: a e b nulli")
        return None
    elif (a==0): #condizione soluzione impossibile
        print("Equazione impossibile: a nullo")
        return None
    else: #altrimenti calcolo la soluzione e la restituisco
        return -b/a

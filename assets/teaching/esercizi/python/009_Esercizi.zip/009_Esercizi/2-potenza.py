def potenza(b,e):
    if e==0:
        return 1
    return potenza(b,e-1)*b

def interi(t):
    """Verifica che t sia una tupla di soli interi"""
    for i in range(len(t)):
        if type(t[i]) != int: 
            return False #basta un controesempio per dire che la proprieta' non e' verificata
    return True #se arrivo qui, proprieta' verificata
    

def somma(t):
    """Funzione che verifica che ogni elemento della tupla
    eccetto il primo sia maggiore della somma dei precedenti"""
    if not interi(t):
        return False
    if len(t)==0: #visto che accumulo dal primo elemento, caso 0 a parte
        return True
    somma = t[0] 
    i = 1 #parto dal secondo elemento 
    while i < len(t):
        if t[i] <= somma:
            return False
        somma += t[i]
        i += 1
    return True #return fuori dal ciclo: se sono qui ho verificato la proprieta'



#False
print(interi(('ciao',)))
print(interi((1,2,3.14)))
print(interi((1,2,3,(4,5))))
print()
      
#True
print(interi(()))
print(interi((1,)))
print(interi((1,2,3)))
print()

#False
print(somma((3,4,5)))
print(somma((1,1)))
print()

#True
print(somma(()))
print(somma((1,2,4)))
t = ()
e = 1
s = 0
for k in range(100):
    t += (e,)
    s += e
    e = s + 1
print(somma(t))
    
      

import string

def normalizza(stringa):
    """Funzione che restituisce una nuova stringa, ripulita da: spazi e punteggiatura"""
    stringa_pulita = ''
    for c in stringa:
        if c not in string.punctuation and c not in string.whitespace:
            stringa_pulita = stringa_pulita+c
    return stringa_pulita

def palindroma(s):
    """Funzione che stabilisce se s è palindroma"""
    s = normalizza(s)
    return s == s[::-1]

def palindroma2(s):
    """Funzione che stabilisce se s è palindroma (senza usare operatore di slicing)"""
    s = normalizza(s)
    if len(s)<2:
        return True #una stringa lunga 0 o 1 è palindroma per def
    for i in range(len(s)//2): #scorro metà stringa (vado da 0 alla metà arrotondata -1)
        if s[i] != s[-1-i]: #controllo i caratteri corrispondenti
            return False #mi basta un carattere non uguale per terminare
    return True #se sono arrivato fin qui, e' palindroma 

import Es1L08 as ol

def unisciOrdinate(L1, L2):
    if (not ol.ordinataCrescente(L1)) or (not ol.ordinataCrescente(L2)):
        return "Le liste devono essere ordinate in modo crescente"
    LR = []
    i = 0
    j = 0
    while i<len(L1) and j<len(L2):
        if L1[i]<=L2[j]:
            LR.append(L1[i])
            i+=1
        else:
            LR.append(L2[j])
            j+=1

    if i<len(L1):
        LR = LR + L1[i:]
    else:
        LR = LR + L2[j:]

    return LR
    

print(unisciOrdinate([3,1,2], [1,2,3]))
print(unisciOrdinate([], []))
print(unisciOrdinate([1,3,5], []))
print(unisciOrdinate([], [1,3,6]))
print(unisciOrdinate([1,3,5], [0,2,4,6,8,10]))
print(unisciOrdinate([100], list(range(1,99,3))))
